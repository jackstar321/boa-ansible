from pydantic import BaseModel,EmailStr
#from database import datetime


class StudentBase(BaseModel):
    name: str
    sclass: str
    section: str


class StudentCreate(StudentBase):
    pass


class Stu(StudentBase):
    name: str
    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    id: int
    email: EmailStr
    password: str

class UserOut(BaseModel):
    email: EmailStr

    class Config:
        orm_modev= True