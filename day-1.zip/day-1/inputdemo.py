
# this is for comments

data1=input('Enter numeric')

c=int(data1)+10
print(c)