
print("welcome to python")

a=10
a="hello"
A=13.45
b="hello"

print(a, b)

myname="Amarjeet"
city='pune'
pin=12345

print(f"My Name is {myname} ,my city is {city} and pin is {pin}")

if 10 > 5:
    print('this is true')