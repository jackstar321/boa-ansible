# Template, self is ref to the current instance of the class
class User:
    
    def __init__(self,name,age):
        self.name=name
        self.age=age


user=User("Suresh",30)

print(user.name,user.age)
