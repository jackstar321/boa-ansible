
#import packages
from abc import ABC,abstractmethod
# parent class

class Bank(ABC):
    @abstractmethod
    def deposit(self):
        pass
   

# child class
class SBI(Bank):
    def deposit(self):
        return "deposit"
    def openFD(self):
        return "FD"

user=SBI()
print(user.deposit())
print(user.openFD())