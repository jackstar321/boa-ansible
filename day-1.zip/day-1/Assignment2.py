
class Student:
    def __init__(self, rollno, name, subject, totalmarks):
        self.rollno = rollno
        self.name = name
        self.subject = subject
        self.totalmarks = totalmarks

    def displayData(self):
        print(f"The Name and subject of student is {
              self.name} , {self.subject}")

    def __str__(self):
        return f"{self.rollno}, {self.name},{self.subject}, {self.totalmarks}"

# create the object


sayna = Student("199", "sanya", "Maths", "99")
mahesh = Student("109", "mahesh", "Phy", "98")

# display the object into human readable string we use __str__


# sayna.displayData()
# mahesh.displayData()

print(mahesh)
print(sayna)
