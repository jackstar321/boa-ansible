
# declaring the function 
def shoWelcome():
    print('welcome to python')
# calling it
shoWelcome()

# calculator
 
def calculatorAdd(x,y):
    return x+y

response= calculatorAdd(12,34)
print(f"The addition is {response}")
