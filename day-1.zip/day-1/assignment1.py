
userAge = input('Enter Your age')

age = int(userAge)

# check the condition
if (age < 0):
    print('Enter valid age')
elif (age < 18):
    print('You are not allowed to vote')
elif (age >= 18 and age < 65):
    print('You are allowed')
else:
    print('you are senior most')
