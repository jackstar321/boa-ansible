

import moduledemo as md

from math  import *

print(md.multi(3,7))

print(sqrt(4))