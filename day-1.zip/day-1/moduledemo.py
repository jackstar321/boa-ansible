

def add(x, y):
    return x+y


def multi(x, y):
    return x*y


def area_of_circle(r):
    pi=3.14
    area=pi*(r*r)
    return area

dummyValue='this is dummy value'